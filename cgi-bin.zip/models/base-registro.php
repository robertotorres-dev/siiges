<?php
  /**
  * Clase que gestiona métodos a nivel registro
  */
  
  require_once "base-general.php";
  
  class Registro extends General
  {
    // Constructor
		public function __construct( )
    {
      parent::__construct( );
    }
		
		
		// Programar métodos para gestionar bitácora de registros
  }
?>