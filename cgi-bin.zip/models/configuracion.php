<?php
  /**
  * Archivo que define las constantes del sistema
  */

	//Local
  //define( "DB_HOST", "localhost" );
  //define( "DB_USER", "root" );
  //define( "DB_PASS", "" );
  //define( "DB_NAME", "siiga_jalisco" );
  //define( "DB_CHARSET", "utf8" );

	//Server
	define( "DB_HOST", "localhost" );
	define( "DB_USER", "siigesjalisco" );
	define( "DB_PASS", "7tb}ubFLH;1Z" );
	define( "DB_NAME", "siiges_jalisco" );
	define( "DB_CHARSET", "utf8" );
?>
